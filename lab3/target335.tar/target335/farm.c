/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_231()
{
    return 3284633928U;
}

void setval_262(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_491()
{
    return 2496104776U;
}

unsigned addval_151(unsigned x)
{
    return x + 2425378992U;
}

unsigned getval_127()
{
    return 3351857221U;
}

unsigned getval_387()
{
    return 2421687189U;
}

unsigned addval_455(unsigned x)
{
    return x + 2417536438U;
}

unsigned addval_409(unsigned x)
{
    return x + 3281025195U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_390(unsigned *p)
{
    *p = 3372796557U;
}

void setval_371(unsigned *p)
{
    *p = 3285616835U;
}

unsigned getval_440()
{
    return 3767091361U;
}

void setval_477(unsigned *p)
{
    *p = 3675832713U;
}

unsigned addval_122(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_180(unsigned x)
{
    return x + 2430634824U;
}

unsigned getval_130()
{
    return 3376988553U;
}

unsigned getval_414()
{
    return 2425411213U;
}

unsigned addval_377(unsigned x)
{
    return x + 3380139657U;
}

unsigned getval_318()
{
    return 3536109961U;
}

void setval_131(unsigned *p)
{
    *p = 2425476745U;
}

unsigned getval_389()
{
    return 3527983497U;
}

void setval_401(unsigned *p)
{
    *p = 2462157305U;
}

void setval_275(unsigned *p)
{
    *p = 3268053366U;
}

unsigned addval_224(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_212(unsigned x)
{
    return x + 3223898761U;
}

unsigned getval_247()
{
    return 2497743176U;
}

unsigned addval_107(unsigned x)
{
    return x + 3281049225U;
}

unsigned addval_199(unsigned x)
{
    return x + 3770930697U;
}

unsigned addval_357(unsigned x)
{
    return x + 2430642504U;
}

unsigned getval_149()
{
    return 2464188744U;
}

unsigned getval_482()
{
    return 3284240863U;
}

unsigned addval_125(unsigned x)
{
    return x + 2425411209U;
}

unsigned addval_292(unsigned x)
{
    return x + 3525364361U;
}

unsigned addval_291(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_437()
{
    return 3373848201U;
}

unsigned getval_163()
{
    return 3682910601U;
}

void setval_421(unsigned *p)
{
    *p = 3373842825U;
}

unsigned getval_435()
{
    return 3374369421U;
}

void setval_159(unsigned *p)
{
    *p = 3229928073U;
}

void setval_276(unsigned *p)
{
    *p = 3525888649U;
}

unsigned addval_264(unsigned x)
{
    return x + 3682912777U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
